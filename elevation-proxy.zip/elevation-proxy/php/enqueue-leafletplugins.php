<?php
/**
 * Functions for enqueuing Leaflet plugins
 *
 * @package Extensions for Leaflet Map
 */

// Direktzugriff auf diese Datei verhindern.
defined( 'ABSPATH' ) || die();
